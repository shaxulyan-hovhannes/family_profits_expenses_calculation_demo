const http = require("http"),

    fs = require("fs"),

    path = require("path"),

    load = require("./server_custom_modules/load_static_file.js"),

    mysql = require("mysql");

var family_members_collect = "";

var loginData, loginMail, baseData;

var [salary_sum, business_sum, pension_sum, grants_sum, helping_sum, other_profits_sum] = [0, 0, 0, 0, 0, 0];

var [health_sum, food_sum, clothes_sum, communal_pays_sum] = [0, 0, 0, 0];

var [kids_sum, men_sum, women_sum, household_sum] = [0, 0, 0, 0];

var [furniture_sum, electronics_sum, car_sum, real_estate_sum] = [0, 0, 0, 0];

var [entertainment_leisure_sum, hobbies_sum, pets_sum, alcohol_sum] = [0, 0, 0, 0];

var [cigarettes_sum, other_expenses_sum] = [0, 0];





const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'amadeus',
});

con.query("CREATE DATABASE IF NOT EXISTS f_p_e_db", (err, result) => {
    if (err) throw err;
    console.log('Database f_p_e_db created');
});

con.query("use f_p_e_db", (err, result) => {
    if (err) throw err;
    console.log("f_p_e is using");
});

con.query('CREATE TABLE IF NOT EXISTS users_tab (user_id INT AUTO_INCREMENT PRIMARY KEY, firstName VARCHAR(255), lastName VARCHAR(255), mail VARCHAR(255) UNIQUE, password VARCHAR(255), family_members VARCHAR(60000), salary INT, business INT, pension INT, grants INT, helping INT, other_profits INT, health INT, food INT, clothes INT, communal_pays INT, kids INT, men INT, women INT, household INT, furniture INT, electronics INT, car INT, real_estate INT, entertainment_leisure INT, hobbies INT, pets INT, alcohol INT, cigarettes INT, other_expenses INT)', (err, result) => {
    if (err) throw err;
    console.log("users_tab created");
});


const server = http.createServer();

server.on("request", (req, res) => {

    if (req.url == "/test") {

        res.write("Test");

        res.end()
    }

    else if (req.url == "/registration") {

        if (req.method == "POST" && req.url == "/registration") {

            req.on("data", (chunk) => {

                console.log(JSON.parse(chunk));

                console.log("Registration data got on /registration");

                var {firstName, lastName, mail, password, photos, general_photo} = JSON.parse(chunk);

                var family_members = firstName + "/";


                var regValue = [[firstName, lastName, mail, password, family_members, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]];

                var inserting = "INSERT INTO users_tab (firstName, lastName, mail, password, family_members, salary, business, pension, grants, helping, other_profits, health, food, clothes, communal_pays, kids, men, women, household, furniture, electronics, car, real_estate, entertainment_leisure, hobbies, pets, alcohol, cigarettes, other_expenses) VALUES ?";

                con.query(inserting, [regValue], (err, result) => {

                    if (err) {

                        console.log(err);
                    }
                    else {
                        console.log("data inserted");
                    }
                });
                res.end("Գրանցումը հաջող ընթացավ։");
            })
        }
        else {
            loadStatic(req, res, './registration', './registration.html');
        }
    }

    else if (req.url == "/login") {
        if (req.method == "POST" && req.url == "/login"){
            req.on("data", (chunk) => {

                console.log(JSON.parse(chunk));

                family_members_collect = "";

                loginData = JSON.parse(chunk);

                loginMail = loginData["mail"];

                var sql = "SELECT * FROM users_tab WHERE mail = ?";

                var logValue = [loginMail];

                con.query(sql, [logValue], (err, result) => {

                    if (err) throw err;

                    baseData = result;

                        if (new Date().getDate() == 1) {

                            var sql = "UPDATE users_tab SET salary = 0, business = 0, pension = 0, grants = 0, helping = 0, other_profits = 0, health = 0, food = 0, clothes = 0, communal_pays = 0, kids = 0, men = 0, women = 0, household = 0, furniture = 0, electronics = 0, car = 0, real_estate = 0, entertainment_leisure = 0, hobbies = 0, pets = 0, alcohol = 0, cigarettes = 0, other_expenses = 0 WHERE user_id = ?";

                            var where_Id = baseData[0].user_id;

                            con.query(sql, [where_Id], (err, result) => {
                                if (err) throw err;
                                console.log("Profits and Expenses updated to 0");
                            });
                        }

                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] == baseData[0].password)) {

                        res.end("Ողջույն " + baseData[0].firstName + ":");
                    }

                    if ((typeof(baseData[0]) != "undefined") && (loginData['mail'] == baseData[0].mail) && (loginData['password'] != baseData[0].password)) {

                        res.end("Գաղտնաբառը սխալ եք մուտքգրել։")
                    }

                    if (typeof(baseData[0]) == "undefined") {
                        res.end("Այսպիսի օգտատեր գոյություն չունի։")
                    }
                });
            })
        }
        else {
            loadStatic(req, res, "./login", "./login.html");
        }
    }

    else if (req.url == "/login_user") {

        var select_login_user = "SELECT * from users_tab where user_id= ?"

        con.query(select_login_user, [baseData[0].user_id], (err, result) => {

            if (err) throw err;

            res.write(JSON.stringify(result[0]));

            res.end();
        })
    }

    else if (req.url == "/profile") {

        if (req.method == "POST") {

            req.on("data", (chunk) => {

                if ("add_family_member" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["family_member"]) {

                        console.log(JSON.parse(chunk));

                        family_members_collect = family_members_collect + JSON.parse(chunk)["family_member"] + "/";

                        var where_Id = baseData[0].user_id;

                        var update_family_member = baseData[0]["family_members"] + family_members_collect;

                        var update_family_member_sql = "UPDATE users_tab SET family_members= ? WHERE user_id= ?";

                        con.query(update_family_member_sql, [update_family_member, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Ընտանիքի անդամը հաջողությամբ ավելացավ։");
                        });

                        res.end("Ընտանիքի անդամը հաջողությամբ ավելացավ։");
                    }

                    else {
                        res.end("Լրացման դաշտը դատարկ է։")
                    }
                }
            })
        }

        else {

        load(req, res, './profile', './html_files/profile.html');
        }
    }

    else if (req.url == "/profits_update") {
        if (req.method == "POST") {
            req.on("data", (chunk) => {

                if ("salary" in JSON.parse(chunk)) {

                    if (JSON.parse(chunk)["salary"]) {
                        console.log(JSON.parse(chunk));

                        salary_sum = salary_sum + JSON.parse(chunk)["salary"];

                        var salary_updating = baseData[0]["salary"] + salary_sum;

                        var where_Id = baseData[0].user_id;

                        var update_salary_sql = "UPDATE users_tab SET salary= ? WHERE user_id= ?";

                        con.query(update_salary_sql, [salary_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Salary updated։");
                        });
                    }
                }

                if ("business" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["business"]) {
                        console.log(JSON.parse(chunk));

                        business_sum = business_sum + JSON.parse(chunk)["business"];

                        var business_updating = baseData[0]["business"] + business_sum;

                        var where_Id = baseData[0].user_id;

                        var update_business_sql = "UPDATE users_tab SET business= ? WHERE user_id= ?";

                        con.query(update_business_sql, [business_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Business updated։");
                        });
                    }
                }

                if ("pension" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["pension"]) {
                        console.log(JSON.parse(chunk));

                        pension_sum = pension_sum + JSON.parse(chunk)["pension"];

                        var pension_updating = baseData[0]["pension"] + pension_sum

                        var where_Id = baseData[0].user_id;

                        var update_pension_sql = "UPDATE users_tab SET pension= ? WHERE user_id= ?";

                        con.query(update_pension_sql, [pension_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Pension updated։");
                        });
                    }
                }

                if ("grants" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["grants"]) {
                        console.log(JSON.parse(chunk));

                        grants_sum = grants_sum + JSON.parse(chunk)["grants"];

                        var grants_updating = baseData[0]["grants"] + grants_sum;

                        var where_Id = baseData[0].user_id;

                        var update_grants_sql = "UPDATE users_tab SET grants= ? WHERE user_id= ?";

                        con.query(update_grants_sql, [grants_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Grants updated։");
                        });
                    }
                }

                if ("helping" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["helping"]) {
                        console.log(JSON.parse(chunk));

                        helping_sum = helping_sum + JSON.parse(chunk)["helping"];

                        var helping_updating = baseData[0]["helping"] + helping_sum;

                        var where_Id = baseData[0].user_id;

                        var update_helping_sql = "UPDATE users_tab SET helping= ? WHERE user_id= ?";

                        con.query(update_helping_sql, [helping_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Helping updated։");
                        });
                    }
                }

                if ("other_profits" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["other_profits"]) {
                        console.log(JSON.parse(chunk));

                        other_profits_sum = other_profits_sum + JSON.parse(chunk)["other_profits"];

                        var other_profits_updating = baseData[0]["other_profits"] + other_profits_sum;

                        var where_Id = baseData[0].user_id;

                        var update_other_profits_sql = "UPDATE users_tab SET other_profits= ? WHERE user_id= ?";

                        con.query(update_other_profits_sql, [other_profits_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Other Profits updated։");
                        });
                    }
                }

                res.end("Եկամուտի տվյալները թարմացան։")
            })
        }
        else {
            res.end()
        }
    }

    else if (req.url == "/expenses_update") {
        if (req.method == "POST") {
            req.on("data", (chunk) => {

                if ("health" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["health"]) {
                        console.log(JSON.parse(chunk));

                        health_sum = health_sum + JSON.parse(chunk)["health"];

                        var health_updating = baseData[0]["health"] + health_sum;

                        var where_Id = baseData[0].user_id;

                        var update_health_sql = "UPDATE users_tab SET health= ? WHERE user_id= ?";

                        con.query(update_health_sql, [health_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Health updated");
                        });
                    }
                }

                if ("food" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["food"]) {
                        console.log(JSON.parse(chunk));

                        food_sum = food_sum + JSON.parse(chunk)["food"];

                        var food_updating = baseData[0]["food"] + food_sum;

                        var where_Id = baseData[0].user_id;

                        var update_food_sql = "UPDATE users_tab SET food= ? WHERE user_id= ?";

                        con.query(update_food_sql, [food_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Food updated");
                        });
                    }
                }
                  if ("clothes" in JSON.parse(chunk)) {
                        if (JSON.parse(chunk)["clothes"]) {
                            console.log(JSON.parse(chunk));

                            clothes_sum = clothes_sum + JSON.parse(chunk)["clothes"];

                            var clothes_updating = baseData[0]["clothes"] + clothes_sum;

                            var where_Id = baseData[0].user_id;

                            var update_clothes_sql = "UPDATE users_tab SET clothes= ? WHERE user_id= ?";

                            con.query(update_clothes_sql, [clothes_updating, where_Id], (err, result) => {

                                if (err) throw err;

                                console.log("Clothes updated");
                            });
                    }
                }

                if ("communal_pays" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["communal_pays"]) {
                        console.log(JSON.parse(chunk));

                        communal_pays_sum = communal_pays_sum + JSON.parse(chunk)["communal_pays"];

                        var communal_pays_updating = baseData[0]["communal_pays"] + communal_pays_sum;

                        var where_Id = baseData[0].user_id;

                        var update_communal_pays_sql = "UPDATE users_tab SET communal_pays= ? WHERE user_id= ?";

                        con.query(update_communal_pays_sql, [communal_pays_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Communal Pays updated");
                        });
                    }
                }

                if ("kids" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["kids"]) {
                        console.log(JSON.parse(chunk));

                        kids_sum = kids_sum + JSON.parse(chunk)["kids"];

                        var kids_updating = baseData[0]["kids"] + kids_sum;

                        var where_Id = baseData[0].user_id;

                        var update_kids_sql = "UPDATE users_tab SET kids= ? WHERE user_id= ?";

                        con.query(update_kids_sql, [kids_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Kids updated");
                        });
                    }
                }

                if ("men" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["men"]) {
                        console.log(JSON.parse(chunk));

                        men_sum = men_sum + JSON.parse(chunk)["men"];

                        var men_updating = baseData[0]["men"] + men_sum;

                        var where_Id = baseData[0].user_id;

                        var update_men_sql = "UPDATE users_tab SET men= ? WHERE user_id= ?";

                        con.query(update_men_sql, [men_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Men updated");
                        });
                    }
                }

                if ("women" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["women"]) {
                        console.log(JSON.parse(chunk));

                        women_sum = women_sum + JSON.parse(chunk)["women"];

                        var women_updating = baseData[0]["women"] + women_sum;

                        var where_Id = baseData[0].user_id;

                        var update_women_sql = "UPDATE users_tab SET women= ? WHERE user_id= ?";

                        con.query(update_women_sql, [women_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Women updated");
                        });
                    }
                }

                if ("household" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["household"]) {
                        console.log(JSON.parse(chunk));

                        household_sum = household_sum + JSON.parse(chunk)["household"];

                        var household_updating = baseData[0]["household"] + household_sum;

                        var where_Id = baseData[0].user_id;

                        var update_household_sql = "UPDATE users_tab SET household= ? WHERE user_id= ?";

                        con.query(update_household_sql, [household_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Household updated");
                        });
                    }
                }

                if ("furniture" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["furniture"]) {
                        console.log(JSON.parse(chunk));

                        furniture_sum = furniture_sum + JSON.parse(chunk)["furniture"];

                        var furniture_updating = baseData[0]["furniture"] + furniture_sum;

                        var where_Id = baseData[0].user_id;

                        var update_furniture_sql = "UPDATE users_tab SET furniture= ? WHERE user_id= ?";

                        con.query(update_furniture_sql, [furniture_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("Furniture updated");
                        });
                    }
                }

                if ("electronics" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["electronics"]) {
                        console.log(JSON.parse(chunk));

                        electronics_sum = electronics_sum + JSON.parse(chunk)["electronics"];

                        var electronics_updating = baseData[0]["electronics"] + electronics_sum;

                        var where_Id = baseData[0].user_id;

                        var update_electronics_sql = "UPDATE users_tab SET electronics= ? WHERE user_id= ?";

                        con.query(update_electronics_sql, [electronics_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("electronics updated");
                        });
                    }
                }

                if ("car" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["car"]) {
                        console.log(JSON.parse(chunk));

                        car_sum = car_sum + JSON.parse(chunk)["car"];

                        var car_updating = baseData[0]["car"] + car_sum;

                        var where_Id = baseData[0].user_id;

                        var update_car_sql = "UPDATE users_tab SET car= ? WHERE user_id= ?";

                        con.query(update_car_sql, [car_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("car updated");
                        });
                    }
                }

                if ("real_estate" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["real_estate"]) {
                        console.log(JSON.parse(chunk));

                        real_estate_sum = real_estate_sum + JSON.parse(chunk)["real_estate"];

                        var real_estate_updating = baseData[0]["real_estate"] + real_estate_sum;

                        var where_Id = baseData[0].user_id;

                        var update_real_estate_sql = "UPDATE users_tab SET real_estate= ? WHERE user_id= ?";

                        con.query(update_real_estate_sql, [real_estate_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("real_estate updated");
                        });
                    }
                }

                if ("entertainment_leisure" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["entertainment_leisure"]) {
                        console.log(JSON.parse(chunk));

                        entertainment_leisure_sum = entertainment_leisure_sum +JSON.parse(chunk)["entertainment_leisure"];

                        var entertainment_leisure_updating = baseData[0]["entertainment_leisure"] + entertainment_leisure_sum;

                        var where_Id = baseData[0].user_id;

                        var update_entertainment_leisure_sql = "UPDATE users_tab SET entertainment_leisure= ? WHERE user_id= ?";

                        con.query(update_entertainment_leisure_sql, [entertainment_leisure_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("entertainment_leisure updated");
                        });
                    }
                }

                if ("hobbies" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["hobbies"]) {
                        console.log(JSON.parse(chunk));

                        hobbies_sum = hobbies_sum + JSON.parse(chunk)["hobbies"];

                        var hobbies_updating = baseData[0]["hobbies"] + hobbies_sum;

                        var where_Id = baseData[0].user_id;

                        var update_hobbies_sql = "UPDATE users_tab SET hobbies= ? WHERE user_id= ?";

                        con.query(update_hobbies_sql, [hobbies_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("hobbies updated");
                        });
                    }
                }

                if ("pets" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["pets"]) {
                        console.log(JSON.parse(chunk));

                        pets_sum = pets_sum + JSON.parse(chunk)["pets"];

                        var pets_updating = baseData[0]["pets"] + pets_sum;

                        var where_Id = baseData[0].user_id;

                        var update_pets_sql = "UPDATE users_tab SET pets= ? WHERE user_id= ?";

                        con.query(update_pets_sql, [pets_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("pets updated");
                        });
                    }
                }

                if ("alcohol" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["alcohol"]) {
                        console.log(JSON.parse(chunk));

                        alcohol_sum = alcohol_sum + JSON.parse(chunk)["alcohol"];

                        var alcohol_updating = baseData[0]["alcohol"] + alcohol_sum;

                        var where_Id = baseData[0].user_id;

                        var update_alcohol_sql = "UPDATE users_tab SET alcohol= ? WHERE user_id= ?";

                        con.query(update_alcohol_sql, [alcohol_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("alcohol updated");
                        });
                    }
                }


                if ("cigarettes" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["cigarettes"]) {
                        console.log(JSON.parse(chunk));

                        cigarettes_sum = cigarettes_sum + JSON.parse(chunk)["cigarettes"];

                        var cigarettes_updating = baseData[0]["cigarettes"] + cigarettes_sum;

                        var where_Id = baseData[0].user_id;

                        var update_cigarettes_sql = "UPDATE users_tab SET cigarettes= ? WHERE user_id= ?";

                        con.query(update_cigarettes_sql, [cigarettes_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("cigarettes updated");
                        });
                    }
                }

                if ("other_expenses" in JSON.parse(chunk)) {
                    if (JSON.parse(chunk)["other_expenses"]) {
                        console.log(JSON.parse(chunk));

                        other_expenses_sum = other_expenses_sum + JSON.parse(chunk)["other_expenses"];

                        var other_expenses_updating = baseData[0]["other_expenses"] + other_expenses_sum;

                        var where_Id = baseData[0].user_id;

                        var update_other_expenses_sql = "UPDATE users_tab SET other_expenses= ? WHERE user_id= ?";

                        con.query(update_other_expenses_sql, [other_expenses_updating, where_Id], (err, result) => {

                            if (err) throw err;

                            console.log("other_expenses updated");
                        });
                    }
                }

                res.end("Ծախսերի տվյալները թարմացան")
            })
        }
        else {
            res.end()
        }
    }

    else {
        load(req, res, './', './html_files/registration_login.html');
    }
}).listen(10001);

console.log("Server running on 10001");

