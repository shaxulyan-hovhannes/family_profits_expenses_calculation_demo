    const LOGO = $("header img"),
        APP_TITLE = $("header h1"),
        ALREADY_REGISTERED_BUTTON = $("main > button"),

        REGISTRATION_FORM = $(".registration_form"),

        LOGIN_FORM = $(".login_form"),

        REG_BTN_FROM_LOGIN = $("input[type='button'");

    LOGO.click(function () {
        window.location = "http://localhost:10001/";
    })

    APP_TITLE.animate({
        opacity: "1"
    }, 1200);

    setTimeout(function () {
        REGISTRATION_FORM.fadeIn(800);

        ALREADY_REGISTERED_BUTTON.animate({
            width: "toggle"
        }, 200);
    }, 1201);

    ALREADY_REGISTERED_BUTTON.on({
        mouseenter: function () {
            $(this).css({
                letterSpacing: "0.8vw",
                fontWeight: "bold",
            })
        },

        mousedown: function () {
            $(this).css({
                border: "0.2vw inset rgb(221, 221, 221)"
            })
        },

        mouseup: function () {
            $(this).css({
                border: "0.2vw outset rgb(221, 221, 221)"
            })
        },

        click: function () {
            $(this).hide(100);

            REGISTRATION_FORM.animate({
                height: "toggle"
            }, 700, function () {
                LOGIN_FORM.animate({
                    height: "toggle"
                }, 800);
            });
        }
    });

    REG_BTN_FROM_LOGIN.on({
        click: function () {
            LOGIN_FORM.animate({
                height: "toggle"
            }, 700, function () {
                REGISTRATION_FORM.animate({
                    height: "toggle"
                }, 800);
            });

            setTimeout(function () {
                ALREADY_REGISTERED_BUTTON.fadeIn(10)
            }, 1300);
        }
    });
