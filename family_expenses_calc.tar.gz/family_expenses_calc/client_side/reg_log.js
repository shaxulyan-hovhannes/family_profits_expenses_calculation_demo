    const TEXT_INPUT = "input[type='text']",

        EMAIL_INPUT = "input[type='email']",

        PASSWORD_INPUT = "input[type='password']";

    var [user, keys] = [{}, ["firstName", "lastName", "mail", "password", ["mail", "password"]]];

    user.correct = 0;

    user.full = 0;

    function isError(input, text) {
        input.css("background", "rgba(255, 0, 0, 0.4");
        input.attr("title", text);
        user.correct = 1;
    };

    function isValid(input) {
        input.css("background", "rgba(0, 255, 0, 0.4");
        input.removeAttr("title");
        user.correct = 1;
    };

    function isEmpty(message) {
        $("input").not($("input[type='submit']")).css({

            background: "rgba(0, 0, 0, 0.4)"
        });

        alert(message);
    }

    $(`${TEXT_INPUT}, ${EMAIL_INPUT}, ${PASSWORD_INPUT}`).on({
        keydown: function () {
            if ($(this).val().length == 0) {
                $(this).css("background", "rgba(0, 0, 0, 0.4)");
            }
        },
        keyup: function () {
            isValid($(this));
            if ($(this).val().length < 3) {
                isError($(this), "Մուտքագրել առնվազն 3 տառ։");
            }

            if ($(this).val().match(/[~\\!\\@\\#\\$\\%\\^\\&\\*\\(\\)\\[\\|\\;\\{\\}\\:\\'\\"\\?\\<\\>\\/\\+\\0\\1\\2\\3\\4\\5\\6\\7\\8\\9]/) && ($(this).attr("type") != "email") && ($(this).attr("type") != "password") && ($(this).attr("class") != "reg_confirm_pswd")) {
                isError($(this), "Մուտքագրել միայն տառեր։");
            }

            if (($(this).attr("type") == "email") && (($(this).val().indexOf("@") == -1) || ($(this).val().indexOf(".") == -1))) {
                isError($("input[type='email']"), "Պահանջվող հետևյալ նիշերը՝ [@] կամ [.] բացակայում են։");
            }

            if (($(this).attr("type") == "email") && ($(this).val().slice($(this).val().indexOf(".") + 1).length < 2)) {
                isError($("input[type='email']"), "Բացակայում է դոմենային անունը։");
            }

            if ($(".reg_pswd").val() !== $(".reg_confirm_pswd").val()) {
                isValid($(".reg_pswd"));
                isError($(".reg_confirm_pswd"), "Գաղտնաբառերը չեն համընկնում։");
            }
        }
    });

    function fill_Object_with_input_datas(inputs, key) {

        inputs.val(function (index, value) {
            if (value.length == 0) {

                user.full = 0;

                event.preventDefault();
            }

            else {
                user[key[index]] = value;

                user.full = 1;
            }
        });
    }

    function ajax_Query(url, data, type, errorMessage) {

        $.ajax({

            url: url,

            data: data,

            type: type
        }).done(function (data) {
            alert(data);

            if (data.indexOf("Ողջույն") != -1) {
                window.location = "http://localhost:10001/profile";
            }

            else {
                window.location = "http://localhost:10001/";
            }

            user = {};

            user.correct = 0;

            user.full = 0;
        }).fail(function () {

            alert(errorMessage);
        });
    };

    $("#reg").submit(function (event) {

        fill_Object_with_input_datas($("#reg input").not($("input[type='submit']")).not($("input[type='password']").eq(1)), keys);

        if (user.correct && user.full) {

            ajax_Query("http://localhost:10001/registration", JSON.stringify(user), "POST", "Առաջացել են որոշ սխալներ գրանցման տվյալները ուղարկելուց։");
        }

        else {

            isEmpty("Գրանցման դաշտերը դատարկ են։")

            event.preventDefault();
        }
    });


    $("#log").submit(function (event) {

        fill_Object_with_input_datas($("#log input").not($("input[type='submit']")).not($("input[type='button']")), keys[keys.length - 1]);

        if (user.correct && user.full) {

            ajax_Query("http://localhost:10001/login", JSON.stringify(user), "POST", "Առաջացել են որոշ սխալներ մուտք գործելու տվյալները ուղարկելուց։");
        }
        else {

            isEmpty("Գրանցման դաշտերը դատարկ են։")

            event.preventDefault();
        }
    });



