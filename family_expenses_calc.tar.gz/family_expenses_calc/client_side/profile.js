const PROFIT_INTRO_LINE = $(".profits_year_show"),

    EXPENSES_INTRO_LINE = $(".expenses_year_show"),

    MONTHS = ["Հունվար", "Փետրվար", "Մարտ", "Ապրիլ", "Մայիս", "Հունիս", "Հուլիս", "Օգոստոս", "Սեպտեմբեր", "Հոկտեմբեր", "Նոյեմբեր", "Դեկտեմբեր"];


var loged_user;

function count_Diffrence(first, second) {
    return Math.round((first / (first + second)) * 100);
}


$(".date_now").text(`${new Date().getDate()} ${MONTHS[new Date().getMonth()]} ${new Date().getFullYear()}`);

$.ajax({
    url: "http://localhost:10001/login_user",
    datatype: "json",
    type: "GET"
}).done(function(data) {
    loged_user = JSON.parse(data);
    var  familyMembers = (JSON.parse(data).family_members).split("/");
    console.log(familyMembers);

    for (var i = 0; i < familyMembers.length; i++) {
        $("<p></p>").addClass("family_members").text(familyMembers[i]).insertBefore($(".add_family_member"));
    }
}).fail(function() {
    alert("Առաջացավ սխալ /login_user֊ից տվյալներ ստանալուց։")
})

$(".add_family_member").css("cursor", "pointer").click(function() {
    $("<div class='modal_block1'></div>").appendTo($("body")).css({
        position: "absolute",
        textAlign: "center",
        top: "0",
        zIndex: "100",
        width: "100%",
        height: "99vh",
        background: "rgba(0,0,0,0)"
    });
    $("<input type='text' /> <br />").css({
        width: "35%",
        fontSize: "3vh",
        marginTop: "2vh",
        padding: "0.8vh"
    }).appendTo($(".modal_block1"));

    $("<button>Ավելացնել</button>").css({
        marginTop: "1.5vh",
        padding: "1vh",
        cursor: "pointer"
    }).appendTo($(".modal_block1"));

    $(".modal_block1 button").click(function(){

        var add__tmp_obj = {
            family_member: $(".modal_block1 input").val(),
            add_family_member: "yes"
        }

        $.ajax({

            url: "http://localhost:10001/profile",

            data: JSON.stringify(add__tmp_obj),

            type: "POST"
        }).done(function(data) {
            alert(data);
            location.reload();
        }).fail(function() {
            alert("Առաջացավ սխալ ընանիքի անդամի ավելացնելուց։")
        });

        $(".modal_block1").detach();
    })
});

function update_query(obj, url) {

    obj.click(function() {

        $("<div class='modal_block2'></div>").appendTo($("body")).css({
            position: "absolute",
            textAlign: "center",
            top: "0",
            zIndex: "101",
            width: "100%",
            height: "99vh",
            background: "rgba(0,0,0,0)"
        });
        $("<input type='text' /> <br />").css({
            width: "35%",
            fontSize: "3vh",
            marginTop: "2vh",
            padding: "0.8vh"
        }).appendTo($(".modal_block2"));

        $("<button>Ավելացնել Եկամուտ</button>").css({
            marginTop: "1.5vh",
            padding: "1vh",
            cursor: "pointer"
        }).appendTo($(".modal_block2"));


        $(".modal_block2 button").click(function () {

            var numVal = +($(".modal_block2 input").val());

            if (obj.attr("class") == "salary") {

                var tmp_obj = {
                    salary: numVal
                }
            }

            if (obj.attr("class") == "business") {

                var tmp_obj = {
                    business: numVal
                }
            }

            if (obj.attr("class") == "pension") {

                var tmp_obj = {
                    pension: numVal
                }
            }

            if (obj.attr("class") == "grants") {

                var tmp_obj = {
                    grants: numVal
                }
            }


            if (obj.attr("class") == "helping") {

                var tmp_obj = {
                    helping: numVal
                }
            }

            if (obj.attr("class") == "other_profits") {

                var tmp_obj = {
                    other_profits: numVal
                }
            }

            if (obj.attr("class") == "health") {

                var tmp_obj = {
                    health: numVal
                }
            }

            if (obj.attr("class") == "food") {

                var tmp_obj = {
                    food: numVal
                }
            }

            if (obj.attr("class") == "clothes") {

                var tmp_obj = {
                    clothes: numVal
                }
            }

            if (obj.attr("class") == "communal_pays") {

                var tmp_obj = {
                    communal_pays: numVal
                }
            }

            if (obj.attr("class") == "kids") {

                var tmp_obj = {
                    kids: numVal
                }
            }

            if (obj.attr("class") == "men") {

                var tmp_obj = {
                    men: numVal
                }
            }

            if (obj.attr("class") == "women") {

                var tmp_obj = {
                    women: numVal
                }
            }

            if (obj.attr("class") == "household") {

                var tmp_obj = {
                    household: numVal
                }
            }

            if (obj.attr("class") == "furniture") {

                var tmp_obj = {
                    furniture: numVal
                }
            }

            if (obj.attr("class") == "electronics") {

                var tmp_obj = {
                    electronics: numVal
                }
            }

            if (obj.attr("class") == "car") {

                var tmp_obj = {
                    car: numVal
                }
            }

            if (obj.attr("class") == "real_estate") {

                var tmp_obj = {
                    real_estate: numVal
                }
            }

            if (obj.attr("class") == "entertainment_leisure") {

                var tmp_obj = {
                    entertainment_leisure: numVal
                }
            }

            if (obj.attr("class") == "hobbies") {

                var tmp_obj = {
                    hobbies: numVal
                }
            }

            if (obj.attr("class") == "pets") {

                var tmp_obj = {
                    pets: numVal
                }
            }

            if (obj.attr("class") == "alcohol") {

                var tmp_obj = {
                    alcohol: numVal
                }
            }

            if (obj.attr("class") == "cigarettes") {

                var tmp_obj = {
                    cigarettes: numVal
                }
            }

            if (obj.attr("class") == "other_expenses") {

                var tmp_obj = {
                    other_expenses: numVal
                }
            }

            $.ajax({

                url: url,

                data: JSON.stringify(tmp_obj),

                type: "POST"
            }).done(function (data) {
                alert(data);
                location.reload();
            }).fail(function () {
                alert("Առաջացավ սխալ ընանիքի անդամի ավելացնելուց։")
            });

            $(".modal_block2").detach();

        })
    });
}
update_query($(".salary"), "http://localhost:10001/profits_update");

update_query($(".business"), "http://localhost:10001/profits_update");

update_query($(".pension"), "http://localhost:10001/profits_update");

update_query($(".grants"), "http://localhost:10001/profits_update");

update_query($(".helping"), "http://localhost:10001/profits_update");

update_query($(".other_profits"), "http://localhost:10001/profits_update");

update_query($(".health"), "http://localhost:10001/expenses_update");

update_query($(".food"), "http://localhost:10001/expenses_update");

update_query($(".clothes"), "http://localhost:10001/expenses_update");

update_query($(".communal_pays"), "http://localhost:10001/expenses_update");

update_query($(".kids"), "http://localhost:10001/expenses_update");

update_query($(".men"), "http://localhost:10001/expenses_update");

update_query($(".women"), "http://localhost:10001/expenses_update");

update_query($(".household"), "http://localhost:10001/expenses_update");

update_query($(".furniture"), "http://localhost:10001/expenses_update");

update_query($(".electronics"), "http://localhost:10001/expenses_update");

update_query($(".car"), "http://localhost:10001/expenses_update");

update_query($(".real_estate"), "http://localhost:10001/expenses_update");

update_query($(".entertainment_leisure"), "http://localhost:10001/expenses_update");

update_query($(".hobbies"), "http://localhost:10001/expenses_update");

update_query($(".pets"), "http://localhost:10001/expenses_update");

update_query($(".alcohol"), "http://localhost:10001/expenses_update");

update_query($(".cigarettes"), "http://localhost:10001/expenses_update");

update_query($(".other_expenses"), "http://localhost:10001/expenses_update");

setTimeout(function() {
    console.log(loged_user);

    var profits_sum = loged_user.salary + loged_user.business + loged_user.pension + loged_user.grants + loged_user.helping + loged_user.other_profits;

    var expenses_sum = loged_user.health + loged_user.food + loged_user.communal_pays + loged_user.kids + loged_user.men + loged_user.women + loged_user.household + loged_user.furniture + loged_user.electronics + loged_user.car + loged_user.real_estate + loged_user.entertainment_leisure + loged_user.hobbies + loged_user.pets + loged_user.alcohol + loged_user.cigarettes + loged_user.other_expenses

    $(".profits_intro_year_sum").text(profits_sum);

    $(".expenses_intro_year_sum").text(expenses_sum);

    if (+($(".profits_intro_year_sum").text()) > 0) {

        PROFIT_INTRO_LINE.css("width", count_Diffrence(+$(".profits_intro_year_sum").text(), +$(".expenses_intro_year_sum").text()) + "%");
    }
    else {
        PROFIT_INTRO_LINE.css("opacity", 0);
    }

    if (+($(".expenses_intro_year_sum").text()) > 0) {

    EXPENSES_INTRO_LINE.css("width", count_Diffrence(+$(".expenses_intro_year_sum").text(), +$(".profits_intro_year_sum").text()) + "%");
        }

        else {
            EXPENSES_INTRO_LINE.css("opacity", 0);
    };

        $(".balanse_block").text((loged_user.salary + loged_user.business + loged_user.pension + loged_user.grants + loged_user.helping + loged_user.other_profits) - (loged_user.health + loged_user.food + loged_user.communal_pays + loged_user.kids + loged_user.men + loged_user.women + loged_user.household + loged_user.furniture + loged_user.electronics + loged_user.car + loged_user.real_estate + loged_user.entertainment_leisure + loged_user.hobbies + loged_user.pets + loged_user.alcohol + loged_user.cigarettes + loged_user.other_expenses));

        if (+($(".balanse_block").text()) > 0) {
            $(".balanse_block").css("color", "green");
        }

        else if (+($(".balanse_block").text()) < 0) {
            $(".balanse_block").css("color", "red")
        }

        else {
            $(".balanse_block").css("color", "black");
        }

    function find_width_percent(line, sum) {
        return Math.round((line / sum) * 100)
    }

        $("header button").click(function() {
           $("<div class='analyse_block'></div>").css({
               background: "rgba(255, 255, 255, 0.8)",
               width: "100%",
               height: "210vh",
               position: "absolute",
               top: "0",
               zIndex: "100"
           }).appendTo($("body"));

           $("<p>X</p>").css({
               color: "red",
               fontWeight: "bold",
               fontSize: "5vh",
               float: "right",
               cursor: "pointer"
           }).appendTo($(".analyse_block"));

            $("<div class='lines_block'></div>").css({
                width: "70%",
                margin: "4vh auto 1vh"
            }).appendTo($(".analyse_block"));

            function create_line(line, sum, line_type, background) {
                $("<p></p>").css({
                    background: background,
                    color: "white",
                    borderTopRightRadius: "0.3vw",
                    borderBottomRightRadius: "0.3vw",
                    padding: "2vh",
                    marginBottom: "1vh"
                }).animate({
                    width: find_width_percent(line, sum) + "%"
                }, 3000, function() {
                    //$(this).text(line_type + "  " + find_width_percent(line, sum) + "%");
                    $("<p></p>").text(line_type + "  " + find_width_percent(line, sum) + "%").insertAfter($(this));
                }).appendTo($(".lines_block"));
            }

            if (loged_user.salary) {
                create_line(loged_user.salary, profits_sum, "Աշխատավարձ", "green");
            }

            if (loged_user.business) {
                create_line(loged_user.business, profits_sum, "Բիզնես", "green");
            }

            if (loged_user.pension) {
                create_line(loged_user.pension, profits_sum, "Թոշակ", "green");
            }

            if (loged_user.grants) {
                create_line(loged_user.grants, profits_sum, "Կրթաթոշակ", "green");
            }

            if (loged_user.helping) {
                create_line(loged_user.helping, profits_sum, "Օգնություն", "green")
            }

            if (loged_user.other_profits) {
                create_line(loged_user.other_profits, profits_sum, "Այլ Եկամուտներ", "green");
            }

            if (loged_user.health) {
                create_line(loged_user.health, expenses_sum, "Առողջություն", "red");
            }

            if (loged_user.food) {
                create_line(loged_user.food, expenses_sum, "Սնունդ", "red");
            }

            if (loged_user.clothes) {
                create_line(loged_user.clothes, expenses_sum, "Հագուստ", "red");
            }

            if (loged_user.communal_pays) {
                create_line(loged_user.communal_pays, expenses_sum, "Կոմունալ Վճարներ", "red");
            }

            if (loged_user.kids) {
                create_line(loged_user.kids, expenses_sum, "Երեխաների Ծախս", "red");
            }

            if (loged_user.men) {
                create_line(loged_user.men, expenses_sum, "Տղամարդու Ծախս", "red");
            }

            if (loged_user.women) {
                create_line(loged_user.women, expenses_sum, "Կանացի Ծախս", "red");
            }

            if (loged_user.household) {
                create_line(loged_user.household, expenses_sum, "Տնտեսական Ապրանքներ", "red");
            }

            if (loged_user.furniture) {
                create_line(loged_user.furniture, expenses_sum, "Կահույք", "red")
            }

            if (loged_user.electronics) {
                create_line(loged_user.electronics, expenses_sum, "Էլեկտրոնիկա", "red")
            }

            if (loged_user.car) {
                create_line(loged_user.car, expenses_sum, "Ավտոմեքենա", "red");
            }

            if (loged_user.real_estate) {
                create_line(loged_user.real_estate, expenses_sum, "Անշարժ Գույք", "red");
            }

            if (loged_user.entertainment_leisure) {
                create_line(loged_user.entertainment_leisure, expenses_sum, "Զվարճանք և Հաճույք", "red")
            }

            if (loged_user.hobbies) {
                create_line(loged_user.hobbies, expenses_sum, "Հոբբի", "red");
            }

            if (loged_user.pets) {
                create_line(loged_user.pets, expenses_sum, "Կենդանիներ", "red");
            }

            if (loged_user.alcohol) {
                create_line(loged_user.alcohol, expenses_sum, "Խմիչք", "red");
            }

            if (loged_user.cigarettes) {
                create_line(loged_user.cigarettes, expenses_sum, "Ծխախոտ", "red");
            }

            if (loged_user.other_expenses) {
                create_line(loged_user.other_expenses, expenses_sum, "Այլ ծախսեր", "red")
            }

            $(".analyse_block p:first").click(function() {
                $(".analyse_block").detach();
            })
        });

}, 200);





